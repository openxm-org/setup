#! /bin/sh
# $OpenXM$
# OpenXM/rc/dot.bashrc must be read before execution of this script.
# source ${OpenXM_HOME}/rc/dot.bashrc
#
#LOGFILE=/tmp/httpd-asir2-sh-$$.txt
#LOGFILE=/dev/null
export LOGFILE
#sm1 -f ${OpenXM_HOME}/src/kan96xx/Doc/httpd-asir2.txt > $LOGFILE 2>&1 
sm1 -f ${OpenXM_HOME}/src/kan96xx/Doc/httpd-asir2.txt



