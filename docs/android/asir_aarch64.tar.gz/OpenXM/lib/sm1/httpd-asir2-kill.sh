#! /bin/sh
# $OpenXM$
killall httpd-asir2.sh
rm -rf /tmp/*webasir*




